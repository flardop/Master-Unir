const API_URL = "https://api.jsonblob.com/api/jsonBlob/019e93e8-e523-7f80-867e-ed3712bb8559";

const productList = document.getElementById("product-list");
const summaryList = document.getElementById("summary-list");
const cartTotal = document.getElementById("cart-total");

let carrito;

function formatearPrecio(valor, moneda) {
  return `${valor.toLocaleString("es-ES", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })}${moneda}`;
}

function crearProductoHTML(producto, moneda) {
  const fila = document.createElement("article");
  fila.className = "product-row";
  fila.dataset.sku = producto.sku;

  fila.innerHTML = `
    <div>
      <h3 class="product-title">${producto.title}</h3>
      <p class="product-ref">Ref: ${producto.sku}</p>
    </div>

    <div class="quantity-box">
      <button class="quantity-btn minus-btn" data-sku="${producto.sku}">-</button>
      <div class="quantity-value" id="qty-${producto.sku}">${producto.quantity}</div>
      <button class="quantity-btn plus-btn" data-sku="${producto.sku}">+</button>
    </div>

    <div class="price">${formatearPrecio(producto.price, moneda)}</div>

    <div class="subtotal" id="subtotal-${producto.sku}">
      ${formatearPrecio(producto.price * producto.quantity, moneda)}
    </div>
  `;

  return fila;
}

function renderProductos() {
  productList.innerHTML = "";

  carrito.productos.forEach((producto) => {
    const filaProducto = crearProductoHTML(producto, carrito.currency);
    productList.appendChild(filaProducto);
  });
}

function renderResumen() {
  const datosCarrito = carrito.obtenerCarrito();
  summaryList.innerHTML = "";

  if (datosCarrito.products.length === 0) {
    summaryList.innerHTML = '<p class="message">No hay productos en el carrito.</p>';
  } else {
    datosCarrito.products.forEach((producto) => {
      const item = document.createElement("div");
      item.className = "summary-item";
      item.innerHTML = `
        <span>${producto.title}</span>
        <span>${formatearPrecio(producto.subtotal, datosCarrito.currency)}</span>
      `;

      summaryList.appendChild(item);
    });
  }

  cartTotal.textContent = formatearPrecio(datosCarrito.total, datosCarrito.currency);
}

function actualizarVistaProducto(sku) {
  const producto = carrito.obtenerInformacionProducto(sku);

  if (!producto) {
    return;
  }

  document.getElementById(`qty-${sku}`).textContent = producto.quantity;
  document.getElementById(`subtotal-${sku}`).textContent = formatearPrecio(
    producto.price * producto.quantity,
    carrito.currency
  );

  renderResumen();
}

function agregarEventos() {
  productList.addEventListener("click", (event) => {
    const boton = event.target;
    const sku = boton.dataset.sku;

    if (!sku) {
      return;
    }

    if (boton.classList.contains("plus-btn")) {
      carrito.incrementarUnidad(sku);
      actualizarVistaProducto(sku);
    }

    if (boton.classList.contains("minus-btn")) {
      carrito.decrementarUnidad(sku);
      actualizarVistaProducto(sku);
    }
  });
}

async function cargarProductos() {
  try {
    productList.innerHTML = '<p class="message">Cargando productos...</p>';

    const respuesta = await fetch(API_URL);

    if (!respuesta.ok) {
      throw new Error("No se pudieron cargar los productos");
    }

    const datos = await respuesta.json();
    carrito = new Carrito(datos.products, datos.currency);

    renderProductos();
    renderResumen();
    agregarEventos();
  } catch (error) {
    productList.innerHTML = '<p class="message error">Error al cargar los productos.</p>';
    summaryList.innerHTML = "";
    cartTotal.textContent = "0,00€";
    console.error(error);
  }
}

cargarProductos();
