class Carrito {
  constructor(productos, currency) {
    this.currency = currency;
    this.productos = productos.map((producto) => ({
      sku: producto.SKU,
      title: producto.title,
      price: Number(producto.price),
      quantity: 0
    }));
  }

  actualizarUnidades(sku, cantidad) {
    const producto = this.productos.find((item) => item.sku === sku);

    if (!producto) {
      return;
    }

    producto.quantity = Math.max(0, Number(cantidad));
  }

  incrementarUnidad(sku) {
    const producto = this.obtenerInformacionProducto(sku);

    if (!producto) {
      return;
    }

    this.actualizarUnidades(sku, producto.quantity + 1);
  }

  decrementarUnidad(sku) {
    const producto = this.obtenerInformacionProducto(sku);

    if (!producto) {
      return;
    }

    this.actualizarUnidades(sku, producto.quantity - 1);
  }

  obtenerInformacionProducto(sku) {
    return this.productos.find((item) => item.sku === sku);
  }

  obtenerTotal() {
    let total = 0;

    this.productos.forEach((producto) => {
      total += producto.price * producto.quantity;
    });

    return total;
  }

  obtenerCarrito() {
    const productosSeleccionados = this.productos
      .filter((producto) => producto.quantity > 0)
      .map((producto) => ({
        sku: producto.sku,
        title: producto.title,
        price: producto.price,
        quantity: producto.quantity,
        subtotal: producto.price * producto.quantity
      }));

    return {
      total: this.obtenerTotal(),
      currency: this.currency,
      products: productosSeleccionados
    };
  }
}
